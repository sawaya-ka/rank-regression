# Original numerical source

This snapshot preserves the producing numerical source, configurations, and inputs for the archived parent fingerprint. This README is a packaging note, not the original deployment guide. Install requirements-tested.txt, then run from this directory with PYTHONPATH=src python tools/run_recompute_plan.py --output-dir results --dry-run. The archived code predates the separately documented 19-job repair.
